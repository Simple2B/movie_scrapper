# -*- coding: utf-8 -*-
"""
Code to scrape pages to find some inner specific links;
"""

from fastapi import FastAPI
from fastapi.responses import FileResponse
from typing import Optional
from requests_html import AsyncHTMLSession
import asyncio
import requests
import bs4
import json
import sys
import base64
import time
import lxml
import re
import os
import selenium
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from fake_useragent import UserAgent
import time
import timeit
import requests
from urllib.parse import unquote

chrome_options = Options()
chrome_options.add_argument('--headless')
chrome_options.add_argument('--no-sandbox')
chrome_options.add_argument('--disable-dev-shm-usage')
chrome_options.add_argument('log-level=3')
chrome_options.add_experimental_option(
    "excludeSwitches", ["enable-automation"])
chrome_options.add_experimental_option('useAutomationExtension', False)
chrome_options.add_argument("--disable-blink-features=AutomationControlled")
chrome_options.add_experimental_option(
    "prefs", {"profile.managed_default_content_settings.images": 2})
chrome_options.add_argument("--disable-setuid-sandbox")
chrome_options.add_argument("--remote-debugging-port=9222")  # this
chrome_options.add_argument("--disable-extensions")
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--dns-prefetch-disable")
chrome_options.add_argument("--shm-size=1g")
chrome_options.add_argument("start-maximized")
chrome_options.add_argument("disable-infobars")
chrome_options.add_argument("--window-size=1920,1080")

# Time that generalist function will take searching for the cyberlocks
TIMEOUT_INNER_SECONDS = 250

# ua = UserAgent()
# userAgent = ua.random
# print(userAgent)

# for auth proxies need proxy.zip with Background.js and manifest.js
# PROXY = "11.456.448.110:8080"
# chrome_options.add_argument('--proxy-server=%s' % PROXY)

userAgent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "\
            "(KHTML, like Gecko) Chrome/60.0.3112.50 Safari/537.36"

chrome_options.add_argument('user-agent={}'.format(userAgent))

# regex to check if the link is correct
regex = re.compile(
        r'^(?:http|ftp)s?://'  # http:// or https://
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'  # domain...
        r'localhost|'  # localhost...
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # ...or ip
        r'(?::\d+)?'  # optional port
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)

# Function to get xpath of a html element
def xpath_source(element):
    components = []
    child = element if element.name else element.parent
    for parent in child.parents:  # type: bs4.element.Tag
        siblings = parent.find_all(child.name, recursive=False)
        components.append(
            child.name if 1 == len(siblings) else '%s[%d]' % (
                child.name,
                next(i for i, s in enumerate(siblings, 1) if s is child)
                )
            )
        child = parent
    components.reverse()
    return '/%s' % '/'.join(components)

app = FastAPI()

@app.get("/clean_garbage/{str_key}")
def clean_garbage(str_key):
    if str_key == 'chrome_kill':
        os.system('pkill -f chrome')
        os.system('pkill -f selenium')
        return "garbage clean"
    return False

@app.get("/")
async def root():  # return of the root link of the api
  return FileResponse('docs.pdf')

links_saida_aux = []
global_depth = 0

@app.get("/generalist/{target_link_encoded}")
def generalista(target_link_encoded, q_string: Optional[str],
                q_imdb: Optional[str]):
    '''
    Generalist function that receive the encoded link in base64,
    q_string (most relevant word from movie name) and q_imdb (imdb ID);
    '''
    global TIMEOUT_INNER_SECONDS
    if q_string:
        key_name_movie = q_string
    else:
        key_name_movie = ''
    if q_imdb:
        imdb_key = q_imdb
    else:
        imdb_key = ''
    try:
        webPage = base64.b64decode(target_link_encoded).decode("utf-8")
    except:
        return json.dumps({"list_of_links": "Page not correctly encoded."})
    try:
        if testCloudFlare(webPage):
            return json.dumps({"list_of_links": "CloudFlare"})
    except:
        pass
    browser = webdriver.Chrome(options=chrome_options, executable_path="/usr/local/bin/chromedriver")
    browser.implicitly_wait(8)
    browser.set_page_load_timeout(25)
    pages = list(set([i.strip() for i in open("pagesToSearch.txt", 'r').readlines() if i.strip() != '']))
    blockWords = list(set([i.strip() for i in open("blockwords.txt", 'r').readlines() if i.strip() != '']))
    browser.get(webPage)
    browser.maximize_window()
    time.sleep(3)
    blockWords.append(browser.current_url+"#")
    open('saida.html','w',encoding='utf-8').write(browser.page_source)
    try:
        try:
            body = browser.find_element_by_xpath('/html/body')
            body.click()
            body.send_keys(Keys.PAGE_DOWN)
        except:
            body = browser.find_element_by_css_selector('body')
            body.click()
            body.send_keys(Keys.PAGE_DOWN)
    except:
        pass
    try:
        ActionChains(browser).move_to_element(body).perform()  
    except:
        pass
    links_saida = []
    checker = []
    list_clicked = []
    links_saida_aux = []
    #stop = timeit.default_timer()
    #if (stop-start) >= 30: return links_saida
    start = timeit.default_timer()
    recheck = False
    def procura(browser, links_saida, checker, list_clicked, recheck):
        links_saida_aux = []
        print(list(set(links_saida)))
        if browser.current_url == None or browser.current_url == '': return links_saida
        if any([page in unquote(browser.current_url) for page in pages]):
            if browser.current_url not in links_saida:
                links_saida.append(browser.current_url)
                links_saida += links_saida_aux
                return links_saida
        if recheck and browser.current_url in list_clicked:
            list_clicked.pop(list_clicked.index(browser.current_url))
        stop = timeit.default_timer()
        if (stop-start) >= TIMEOUT_INNER_SECONDS: 
            print("timeOut")
            links_saida += links_saida_aux
            return links_saida        
        if browser.current_url in list_clicked or "#" in browser.current_url:
            print(browser.current_url)
            links_saida += links_saida_aux
            return links_saida
        list_clicked.append(browser.current_url)
        print("oi,",browser.current_url)
        # access_link = [(i, i.get_attribute("href"))  for i in browser.find_elements_by_tag_name('a') if i.get_attribute("href") != None and ("watch" in i.get_attribute("href") or "embed" in i.get_attribute("href") or "=" in i.get_attribute("href")) and i.get_attribute("href") not in list_clicked and all([word not in i.get_attribute('href') for word in blockWords])]
        open('saida.html','w',encoding='utf-8').write(browser.page_source)
        soup = bs4.BeautifulSoup(browser.page_source, features="lxml")
        #key_name_movie = "baby"
        #imdb_key = 'tt9894660'
        list_scrits_click = list(set([(i, i.decode_contents()) for i in soup.find_all('script', type='text/javascript') if i.decode_contents() != None and i.decode_contents() != "" and ".click(" in i.decode_contents()]))
        if key_name_movie != '' and imdb_key != '':
            access_link2 = list(set([(i, i['href']) for i in soup.find_all(attrs={"href":True}) if i['href']!= None and ("embed" in i['href'] or "=" in i['href'] or "?" in i['href'] or "-full" in i['href'] or key_name_movie in i['href'] or imdb_key in i['href']) and i['href'] not in list_clicked and all([word not in i['href'] for word in blockWords]) and not i['href'].endswith('#')]))
        else:
            access_link2 = list(set([(i, i['href']) for i in soup.find_all(attrs={"href":True}) if i['href']!= None and ("embed" in i['href'] or "=" in i['href'] or "?" in i['href'] or "-full" in i['href']) and i['href'] not in list_clicked and all([word not in i['href'] for word in blockWords]) and not i['href'].endswith('#')]))
        access_link = []
        for index, link in enumerate(access_link2):
            if re.match(regex, link[1]) is None:
                link_aux = link[1]
                link_aux = link_aux.replace("blob:","")
                link_aux = link_aux.replace(" ", "")
                link_aux = link_aux.replace("///", "//")
                link_aux = link_aux.replace("////", "//")
                link_aux = link_aux.replace("/////", "//")
                if link_aux.startswith("//"):
                    link_aux = "https:"+link_aux
                elif link_aux.startswith("/"):
                    link_aux = '/'.join(browser.current_url.split("/")[:3])+link_aux          
                link_aux = link_aux[:8]+link_aux[8:].replace("//", "/")
                access_link.append((link[0], link_aux))
            else:
                access_link.append((link[0], link[1]))
        clickable_link = list(set([(xpath_source(i), i['onclick']) for i in soup.find_all(attrs={"onclick":True}) if i['onclick'] != None and re.findall(r'\(([^)]+)', i['onclick']) != [] and i['onclick'] not in list_clicked and "return " not in i['onclick'] and all([word not in i['onclick'] for word in blockWords])])) 
        frames = [(xpath_source(i), i['src']) for i in soup.find_all('iframe', attrs={"src":True}) if i['src'] != None and i['src'] != '' and all([word not in i['src'] for word in blockWords]) and not i['src'].endswith('.php')]
        frames += [(i, i['src']) for i in soup.find_all('video', attrs={"src":True}) if i['src'] != None and i['src'] != '' and all([word not in i['src'] for word in blockWords]) and not i['src'].endswith('.php')]
        frames += [(i, i['data-video']) for i in soup.find_all(attrs={"data-video":True}) if i['data-video'] != None and i['data-video'] != '' and all([word not in i['data-video'] for word in blockWords]) and not i['data-video'].endswith('.php')]
        frames = list(set(frames))
        frames_to_access = []
        frames_boo = False
        for index, frame in enumerate(frames):
            stop = timeit.default_timer()
            if (stop-start) >= TIMEOUT_INNER_SECONDS: 
                print("timeOut2")
                links_saida += links_saida_aux
                return links_saida
            if frame[1] in links_saida: continue
            if any([page in frame[1] for page in pages]):
                if frame[1] not in links_saida:
                    links_saida.append(frame[1])
                    frames_boo = True
                else:
                    frames_to_access.append(frame)
            else:
                frames_to_access.append(frame)
        for index, frame in enumerate(frames_to_access):
            stop = timeit.default_timer()
            if (stop-start) >= TIMEOUT_INNER_SECONDS: 
                print("timeOut2")
                links_saida += links_saida_aux
                return links_saida
            if frames_boo: continue
            try:
                selenium_access_iframe = browser.find_element_by_xpath(frame[0])
                if selenium_access_iframe.tag_name == 'iframe':
                    print('acceess', frame[1])
                    browser.switch_to.frame(selenium_access_iframe)
                    links_saida_aux += procura(browser, links_saida, checker, list_clicked, True)
                    browser.switch_to.parent_frame()
                else:
                    continue
            except:
                browser.switch_to.parent_frame()
                if any([page in unquote(frame[1]) for page in pages]):
                    if frame[1] not in links_saida:
                        links_saida.append(frame[1])
                print('fail', frame[1])
        for index, i in enumerate(clickable_link):
            stop = timeit.default_timer()
            if (stop-start) >= TIMEOUT_INNER_SECONDS: 
                print("timeOut2")
                links_saida += links_saida_aux
                return links_saida
            if i[1] in list_clicked: continue
            try:
                print('Clickou1', i[1])
                num_tabs1 = len(browser.window_handles)
                browser.find_element_by_xpath(i[0]).click()
                time.sleep(1)
                num_tabs2 = len(browser.window_handles)
                if num_tabs2 > num_tabs1:
                    browser.switch_to.window(browser.window_handles[1])
                    links_saida_aux += procura(browser, links_saida, checker, list_clicked, False)
                    browser.close()
                    browser.switch_to.window(browser.window_handles[0])
                else:
                    links_saida_aux += procura(browser, links_saida, checker, list_clicked, False)
                list_clicked.append(i[1])
            except:
                browser.switch_to.window(browser.window_handles[0])
                if any([page in unquote(i[1]) for page in pages]):
                    if i[1] not in links_saida:
                        links_saida.append(i[1])
                print('notClickable1', i[1])
        for index, link in enumerate(access_link):
            stop = timeit.default_timer()
            if (stop-start) >= TIMEOUT_INNER_SECONDS: 
                print("timeOut2")
                links_saida += links_saida_aux
                return links_saida
            if link[1] in links_saida: continue
            if link[1] in list_clicked: continue
            if any([page in link[1] for page in pages]):
                if link[1] not in links_saida:
                    links_saida.append(link[1])
            else:
                try:
                    print('oi2', link[1])
                    browser2 = webdriver.Chrome(options=chrome_options, executable_path="/usr/local/bin/chromedriver")
                    browser2.implicitly_wait(8)
                    browser2.set_page_load_timeout(20)
                    browser2.get(link[1])
                    time.sleep(2)
                    links_saida_aux += procura(browser2, links_saida, checker, list_clicked, False)
                    list_clicked.append(link[1])
                    browser2.quit()
                    print('passou', link[1])
                except:
                    print('erroGet', link[1])
                    links_saida += links_saida_aux
                    return links_saida
        for index, link in enumerate(list_scrits_click):
            stop = timeit.default_timer()
            if (stop-start) >= TIMEOUT_INNER_SECONDS: 
                print("timeOut2")
                links_saida += links_saida_aux
                return links_saida
            st = link[1]
            st2 = st[st[st.find("click(function(){"):].find("{")+st.find("click(function(){"):]
            js = getinnetChaves(st2)
            try:
                print('Clickou2', js)
                if js in list_clicked: continue
                browser.execute_script(js)
                list_clicked.append(js)
                links_saida_aux += procura(browser, links_saida, checker, list_clicked, True)
            except:
                print('notClickable2', link[1])
                browser.switch_to.window(browser.window_handles[0])
        links_saida += links_saida_aux
        return list(set(links_saida))
    links = procura(browser, links_saida, checker, list_clicked, False)
    try:
        browser.quit()
    except:
        pass
    try:
        browser2.quit()
    except:
        pass
    out_final = json.dumps({"list_of_links": "PageEmpty"})
    out_final = finalTest(links, webPage)
    return out_final

def getinnetChaves(st2):
    chaves = 0
    saida = ''
    for letter in st2:
        saida += letter
        if letter == "{":
            chaves += 1
        elif letter == "}":
            chaves -= 1
        if chaves == 0:
            return(saida)

@app.get("/link/{target_link_encoded}")
async def read_item(target_link_encoded):
  try:
    link_entrada = base64.b64decode(target_link_encoded).decode("utf-8")
  except:
    return "Page not correctly encoded."
  # for link_entrada in links_entrada:
  # links_saida = []
  # print(link_entrada)
  try:
      if testCloudFlare(link_entrada):
          return json.dumps({"list_of_links": "CloudFlare"})
  except:
      pass
  try:
      out = getLinks0(link_entrada)
      if len(out) == 0: raise UnboundLocalError(
          'My exit condition was met. Leaving try block')
      # print(out)
      print("Code0")
      return convertToJson(out, link_entrada)
  except:
      pass
  try:
      out = getLinks1(link_entrada)
      if len(out) == 0: raise UnboundLocalError(
          'My exit condition was met. Leaving try block')
      # print(out)
      print("Code1")
      return convertToJson(out, link_entrada)
  except:
      pass
  try:
      out = getLinks2(link_entrada)
      if len(out) == 0: raise UnboundLocalError(
          'My exit condition was met. Leaving try block')
      # print(out)
      print("Code2")
      return convertToJson(out, link_entrada)
  except:
      pass
  try:
      out = getLinks3(link_entrada)
      if len(out) == 0: raise UnboundLocalError(
          'My exit condition was met. Leaving try block')
      # print(out)
      print("Code3")
      return convertToJson(out, link_entrada)
  except:
      pass
  try:
      out = getLinks4(link_entrada)
      if len(out) == 0: raise UnboundLocalError(
          'My exit condition was met. Leaving try block')
      # print(out)
      print("Code4")
      return convertToJson(out, link_entrada)
  except:
      pass
  try:
      out = getLinks5(link_entrada)
      if len(out) == 0: raise UnboundLocalError(
          'My exit condition was met. Leaving try block')
      # print(out)
      print("Code5")
      return convertToJson(out, link_entrada)
  except:
      pass
  try:
      out = getLinks6(link_entrada)
      if len(out) == 0: raise UnboundLocalError(
          'My exit condition was met. Leaving try block')
      # print(out)
      print("Code6")
      return convertToJson(out, link_entrada)
  except:
      pass
  try:
      out = getLinks7(link_entrada)
      if len(out) == 0: raise UnboundLocalError(
          'My exit condition was met. Leaving try block')
      # print(out)
      print("Code7")
      return convertToJson(out, link_entrada)
  except:
    pass
  try:
    #out = await asyncio.gather(getLinks8(link_entrada))
    out = getLinks8(link_entrada)
    if len(out) == 0: raise UnboundLocalError(
        'My exit condition was met. Leaving try block')
    # print(out)
    print("Code8")
    #return convertToJson(out[0], link_entrada)
    return convertToJson(out, link_entrada)
  except:
    pass
  try:
      out = getLinks9(link_entrada)
      if len(out) == 0: raise UnboundLocalError(
          'My exit condition was met. Leaving try block')
      # print(out)
      print("Code9")
      return convertToJson(out, link_entrada)
  except:
    return json.dumps({"list_of_links": "PageNotTreated"})

def finalTest(out, link_entrada):
  saida = {}
  saida['list_of_links'] = []
  for link in out:
    if link != '' and len(link) >= 10:
      if re.match(regex, link) is None:
          link = link.replace("blob:","")
          link = link.replace(" ", "")
          link = link.replace("///", "//")
          link = link.replace("////", "//")
          link = link.replace("/////", "//")
          if link.startswith("//"):
              link = "https:"+link
          elif link.startswith("/"):
              link = '/'.join(link_entrada.split("/")[:3])+link          
          link = link[:8]+link[8:].replace("//", "/")
      saida['list_of_links'].append(link)
  return getMirrorLinks(list(set(saida['list_of_links'])), link_entrada)

def getMirrorLinks(inner_list_links, link_entrada):
    # TODO getGomo.py
    links = []
    for link0 in inner_list_links:
        try:
            link0 = link0.strip()
            if any([page in unquote(link0) for page in ['videostreaming', 'streamingworld', 'vido.fun/', '.xyz/', 'polskastrem', 'playerhost', 'vidnext', 'gomo', 'hls.hdv.fun/', 'gdriveplayer', '123moviesplayer.com/','database.gdriveplayer.me/']]):
                saida = getMirror1(link0)
                if saida == []:
                    saida = getMirror2(link0)
                    if saida == [] and ("imdb" in link0 or "=tt" in link0 or "/tt" in link0):
                        saida = getMirror0(link0)
                        if saida == [] and ("imdb" in link0 or "=tt" in link0 or "/tt" in link0):
                            saida = getMirror3(link0)
                if saida == []:
                    links.append(link0)
            else:
                if link0 not in links:
                    links.append(link0)
        except:
            continue
    return convertToJson(links, link_entrada)

def getMirror0(link_entrada): #https://imdbstream.xyz/
    #print(link_entrada, 0)
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Cache-Control': 'max-age=0',
        'TE': 'Trailers',
    }
    response = requests.get(link_entrada, headers=headers)
    soup2 = bs4.BeautifulSoup(response.text, features="lxml")
    list_links = soup2.findAll('iframe', src=True)
    return([links['src'] for links in list_links])

def getMirror1(link_entrada): #vidnext.net
    #print(link_entrada, 1)
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Cache-Control': 'max-age=0',
        'TE': 'Trailers',
    }
    response = requests.get(link_entrada, headers=headers)
    soup2 = bs4.BeautifulSoup(response.text, features="lxml")
    list_links = soup2.findAll('li', class_='linkserver')
    return([links['data-video'] for links in list_links])

def getMirror2(link_entrada): #gomo, 123movie, playerhost.net
    #print(link_entrada, 2)
    links_saida = []
    try:
        for i in range(10):
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
                'DNT': '1',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
            }
            params = (
                ('src', 'mirror'+str(i)),
            )
            response = requests.get(link_entrada, headers=headers, params=params)
            index = response.text.find('var tc =')+10
            token_code = response.text[index:response.text[index:].find('\';')+index]
            index2 = response.text.find('_token": "')+12
            token = response.text[index2:response.text[index2:].find('",')+index2]
            def getToken(s):
                out = list(s[4:13])
                out.reverse()
                return ''.join(out) + "13" + "444223"
            data = {
            'tokenCode': token_code,
            '_token': token,
            }
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0',
                'Accept': '*/*',
                'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With': 'XMLHttpRequest',
                'Origin': '/'.join(link_entrada.split("/")[:3]),
                'x-token': getToken(token_code),
                'DNT': '1',
                'Connection': 'keep-alive',
            }
            response = requests.post('/'.join(link_entrada.split("/")[:3])+'/decoding_v3.php', headers=headers, data=data)
            links_saida += json.loads(response.text)
    except:
        try:
            links_saida += json.loads(response.text)
        except:
            links_saida += []
    return list(set(links_saida))

def getMirror3(link_entrada): #databasegdriveplayer
    #print(link_entrada, 3)
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Cache-Control': 'max-age=0',
        'TE': 'Trailers',
    }
    response = requests.get(link_entrada, headers=headers)
    soup2 = bs4.BeautifulSoup(response.text, features="lxml")
    list_links = soup2.findAll('a', href=True)
    return([links['href'] for links in list_links if links['href'] != "" and links['href'] != "/" and links['href'] != "javascript:void(0)"])

def convertToJson(out, link_entrada):
  saida = {}
  saida['list_of_links'] = []
  for link in out:
    if link != '' and len(link) >= 10:
      if re.match(regex, link) is None:
          link = link.replace("blob:","")
          link = link.replace(" ", "")
          link = link.replace("///", "//")
          link = link.replace("////", "//")
          link = link.replace("/////", "//")
          if link.startswith("//"):
              link = "https:"+link
          elif link.startswith("/"):
              link = '/'.join(link_entrada.split("/")[:3])+link          
          link = link[:8]+link[8:].replace("//", "/")
      saida['list_of_links'].append(link)
  saida['list_of_links'] = list(set(saida['list_of_links']))
  if saida['list_of_links'] == []:
      return json.dumps({"list_of_links": "PageEmpty"})
  else:
      return json.dumps(saida)

def testCloudFlare(link_entrada):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Cache-Control': 'max-age=0',
        'TE': 'Trailers',
    }
    response = requests.get(link_entrada, headers=headers)
    if "cf-browser-verification cf-im-under-attack" in response.text:
        return True

def getLinks0(link_entrada):
    # link_entrada = 'https://ww1.solarmovie.app/film/tenet'
    # link_entrada = sys.argv[1]

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Cache-Control': 'max-age=0',
        'TE': 'Trailers',
    }

    response = requests.get(link_entrada, headers=headers)

    index = response.text.find('var tok')
    index = response.text[index:].find("'")+index+1

    token = response.text[index:response.text[index:].find("'")+index]

    soup = bs4.BeautifulSoup(response.text, features="lxml")

    idEl = soup.find('a', class_="play")['data-movie']

    index = response.text.find('sociallocker.js?minify=true&v=')
    index = response.text[index:].find("v=")+index+2

    elid = response.text[index:response.text[index:].find('"')+index]

    message = elid
    message_bytes = message.encode('ascii')
    base64_bytes = base64.b64encode(message_bytes)
    base64_message = base64_bytes.decode('ascii')

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Authorization': 'Bearer false',
        'X-Requested-With': 'XMLHttpRequest',
        'Origin': 'https://ww1.solarmovie.app',
        'DNT': '1',
        'Connection': 'keep-alive',
        'TE': 'Trailers',
    }

    data = {
    'action': 'getMovieEmb',
    'idEl': idEl,
    'token': token,
    'nopop': '',
    'elid': base64_message
    }

    response = requests.post('/'.join(link_entrada.split("/")[:3])+'/ajax/vsozrflxcw.php', headers=headers, data=data)
    json_file = json.loads(response.text)

    lista_links = []
    for link in json_file:
        soup = bs4.BeautifulSoup(json_file[link]['embed'], features="lxml")
        lista_links.append(soup.iframe['src'])

    return(lista_links)

def getLinks1(link_entrada):

    # link_entrada = sys.argv[1]
    # link_entrada = 'https://solarmovie123.net/movies/tenet/'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Cache-Control': 'max-age=0',
        'TE': 'Trailers',
    }

    response = requests.get(link_entrada , headers=headers)

    soup = bs4.BeautifulSoup(response.text, features="lxml")

    id = [link['href'] for link in soup.findAll('link') if "p=" in link['href']][0].split("p=")[-1]

    response = requests.get('/'.join(link_entrada.split("/")[:3])+'/wp-json/dooplayer/v1/post/'+id+'?type=movie&source=1', headers=headers)

    link = json.loads(response.text)['embed_url']

    response = requests.get(link, headers=headers)

    soup2 = bs4.BeautifulSoup(response.text, features="lxml")

    list_links = soup2.findAll('li', class_='linkserver')

    return([links['data-video'] for links in list_links])

def getLinks2(link_entrada):

    # link_entrada = 'https://putlockerapp.com/tenet/'

    # link_entrada = sys.argv[1]

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Cache-Control': 'max-age=0',
        'TE': 'Trailers',
    }

    response = requests.get(link_entrada, headers=headers)
    if response.ok:
        pass
    else:
        exit()
        # cloudflare bypass

    index = response.text.find("https://gomo")
    link = response.text[index:response.text[index:].find('"')+index]

    if index == -1:
        if response.text.find('veri":"') == -1: exit()
        index = response.text.find('veri":"')+7
        veri = response.text[index:response.text[index:].find('"')+index]
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0',
            'Accept': '*/*',
            'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With': 'XMLHttpRequest',
            'DNT': '1',
            'Connection': 'keep-alive',
            'TE': 'Trailers',
        }
        data = {
        'veri': veri
        }
        response = requests.post('/'.join(link_entrada.split("/")[:3])+'/islem.php', headers=headers,  data=data)
        link = response.text[13:response.text[13:].find('"')+13]

    link_entrada = link

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }

    params = (
        ('src', 'mirror2'),
    )

    response = requests.get(link_entrada, headers=headers, params=params)
    index = response.text.find('var tc =')+10
    token_code = response.text[index:response.text[index:].find('\';')+index]
    index2 = response.text.find('_token": "')+12
    token = response.text[index2:response.text[index2:].find('",')+index2]
    def getToken(s):
        out = list(s[4:13])
        out.reverse()
        return ''.join(out) + "13" + "444223"

    data = {
    'tokenCode': token_code,
    '_token': token,
    }

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0',
        'Accept': '*/*',
        'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Origin': 'https://gomo.to',
        'x-token': getToken(token_code),
        'DNT': '1',
        'Connection': 'keep-alive',
    }

    response = requests.post('https://gomo.to/decoding_v3.php', headers=headers, data=data)
    return(json.loads(response.text))

def getLinks3(link_entrada):

    # link_entrada = 'https://putlocker-new.site/watch-movie/tenet-2020_cwbmajkzv'

    # link_entrada = sys.argv[1]
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'TE': 'Trailers',
    }

    response = requests.get(link_entrada+'?watchnow=1', headers=headers)

    soup = bs4.BeautifulSoup(response.text, features="lxml")
    return([i.iframe['src'] for i in soup.findAll('div', class_='movieplay')])

def getLinks4(link_entrada):

    # link_entrada = 'https://w2.putlockers.co/movie/tenet/'
    # link_entrada = sys.argv[1]

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'TE': 'Trailers',
    }

    response = requests.get(link_entrada, headers=headers)

    index = response.text.find(link_entrada)
    link = response.text[index:response.text[index:].find('"')+index]
    link_entrada = link

    response = requests.get(link_entrada, headers=headers)

    index = response.text.find("https://playerhost.net/")
    link = response.text[index:response.text[index:].find('"')+index]
    link_entrada = link

    response = requests.get(link_entrada, headers=headers)

    index = response.text.find('var tc =')+10
    token_code = response.text[index:response.text[index:].find('\';')+index]
    index2 = response.text.find('_token": "')+12
    token = response.text[index2:response.text[index2:].find('",')+index2]

    index3 = response.text.find('.slice(')+9
    slicing = int(response.text[index3:response.text[index3:].find(')')+index3])

    def getToken(s, slicing):
        out = list(s[3:slicing])
        out.reverse()
        return ''.join(out) + str(slicing)+"348277"

    data = {
    'tokenCode': token_code,
    '_token': token,
    }

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0',
        'Accept': '*/*',
        'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'x-token': getToken(token_code, slicing),
        'X-Requested-With': 'XMLHttpRequest',
        'Origin': 'https://playerhost.net',
        'DNT': '1',
        'Connection': 'keep-alive',
        'TE': 'Trailers',
    }

    response = requests.post('https://playerhost.net/decoding_v3.php', headers=headers, data=data)
    return(json.loads(response.text))

def getLinks5(link_entrada):

    # link_entrada = 'https://primewire.st/tenet-2020/'
    # link_entrada = sys.argv[1]

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }

    response = requests.get(link_entrada, headers=headers)

    soup = bs4.BeautifulSoup(response.text, features="lxml")

    id = soup.find('div', id='pbar_outerdiv')['data-video']

    response = requests.get('https://databasegdriveplayer.co/player.php?imdb='+id, headers=headers)

    soup = bs4.BeautifulSoup(response.text, features="lxml")

    atags = soup.find('ul', class_='list-server-items')
    lista_links = []
    for i in atags.findAll('a'):
        link = i['href']
        if link.startswith('//'):
            link = 'https:'+link
        else:
            link = 'https://databasegdriveplayer.co'+link
        lista_links.append(link)

    return(lista_links)

def getLinks6(link_entrada):

    # link_entrada = sys.argv[1]
    # link_entrada = 'https://putlockeron.com/religulous/'

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Cache-Control': 'max-age=0',
        'TE': 'Trailers',
    }

    response = requests.get(link_entrada, headers=headers)

    index = response.text.find("https://123moviesplayer.com/movie/")
    link = response.text[index:response.text[index:].find('"')+index]
    link_entrada = link

    response = requests.get(link_entrada, headers=headers)

    index = response.text.find('var tc =')+10
    token_code = response.text[index:response.text[index:].find('\';')+index]
    index2 = response.text.find('_token": "')+12
    token = response.text[index2:response.text[index2:].find('",')+index2]

    index3 = response.text.find('.slice(')+9
    slicing = int(response.text[index3:response.text[index3:].find(')')+index3])

    def getToken(s, slicing):
        out = list(s[7:slicing])
        out.reverse()
        return ''.join(out) + str(slicing)+"761385"

    data = {
    'tokenCode': token_code,
    '_token': token,
    }

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0',
        'Accept': '*/*',
        'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'x-token': getToken(token_code, slicing),
        'X-Requested-With': 'XMLHttpRequest',
        'Origin': 'https://playerhost.net',
        'DNT': '1',
        'Connection': 'keep-alive',
        'TE': 'Trailers',
    }


    response = requests.post('https://123moviesplayer.com/decoding_v3.php', headers=headers, data=data)
    return (json.loads(response.text))

def getLinks7(link_entrada):
    # link_entrada = sys.argv[1]
    # link_entrada = 'https://putlockers.fm/watch/RGbgXVbd-tenet.html'    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Cache-Control': 'max-age=0',
        'TE': 'Trailers',
    }
    
    response = requests.get(link_entrada, headers=headers)
    
    soup = bs4.BeautifulSoup(response.text, features="lxml")
    linksToRequest = [link.a['href'] for link in soup.find_all('p', class_="server_version")]
      
    links_saida = []
    for link in linksToRequest:
        # print("#"*100)
        # print(link)
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                'TE': 'Trailers',
            }
            response = requests.get(link, headers=headers)
            index = response.text.find('Base64.decode("')
            index = response.text[index:].find('"')+index+1
            message = response.text[index:response.text[index:].find('"')+index]
            msg_decode = base64.b64decode(message)
            soup = bs4.BeautifulSoup(msg_decode, features="lxml")
            link = soup.find('iframe')['src']
            links_saida.append(link)
            # print(link)
        except:
            pass
    return (links_saida)


@asyncio.coroutine
async def render_JS(URL, render):
    session = AsyncHTMLSession()
    r = await session.request('get', URL, timeout=4)
    #r = session.get(URL)
    if render:
        await r.html.arender(retries=2, wait=1, timeout=5)
    else:
        pass
    await r.session.close()
    return r.html

@asyncio.coroutine
async def getLinks8(webpage):    
    #webpage = 'https://primewire.unblockit.link/movie/242382-watch-pulp-fiction'
    head = '/'.join(webpage.split("/")[:3])
    loop = asyncio.get_event_loop()
    if loop.is_running() == False:
        saida = loop.run_until_complete(asyncio.gather(render_JS(webpage, True)))
        soup = bs4.BeautifulSoup(saida[0].html, features="lxml")
    else:
        saida = await render_JS(webpage, True)
        soup = bs4.BeautifulSoup(saida.html, features="lxml")
    a = soup.findAll("span", class_='movie_version_link')
    b = soup.findAll("span", class_="version-host")
    linksToRequest = []
    counting = 0
    for i in a:
        if i.a['href'] != 'javascript:void(0)':
            linksToRequest.append([head+i.a['href'], b[counting].text.strip()])
        else:
            linksToRequest.append([head+i.find_all('a')[1]['href'], b[counting].text.strip()])
        counting += 1    
    lista_links = []
    for pair in linksToRequest:
        link = pair[0]
        source = pair[1]
        headers = {
            'accept': '*/*',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'cors',
            'sec-fetch-dest': 'empty',
            'accept-language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        }
        try:        
            response = requests.get(link, headers=headers, timeout=5)
        except:
            continue
        lista_links.append(response.url)        
    return(lista_links)

def getLinks9(link_entrada):
    # link_entrada = 'https://ww4.9movies.yt/film/fit-for-a-prince/60lqg/'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Cache-Control': 'max-age=0',
        'TE': 'Trailers',
    }
    response = requests.get(link_entrada, headers=headers)
    soup = bs4.BeautifulSoup(response.text, features="lxml")
    div_list = soup.find('div', id='list-eps')
    saida_links = []
    for ul in div_list.findAll('ul'):
        eid = ul.a['data-id']    
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With': 'XMLHttpRequest',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Cache-Control': 'max-age=0',
            'TE': 'Trailers',
        }
        data = {
        'eid': eid
        }
        response = requests.post('/'.join(link_entrada.split("/")[:3])+'/ajax/movie_sources/', headers=headers, data=data)
        saida_links.append(json.loads(response.text)['embed'])
    return saida_links

# print(read_item('aHR0cHM6Ly9wdXRsb2NrZXItbmV3LnNpdGUvd2F0Y2gtbW92aWUvdGVuZXQtMjAyMF9jd2JtYWprenYvYnB6dndxNi1mdWxsLW1vdmllLW9ubGluZQ=='))
# print(read_item(base64.b64encode(b'https://primewire.unblockit.link/movie/242382-watch-pulp-fiction')))

# # loop = asyncio.get_event_loop()
# # out = loop.run_until_complete(read_item(base64.b64encode(b'https://primewire.unblockit.link/movie/242382-watch-pulp-fiction')))
# # print(out)

# # loop = asyncio.get_event_loop()
# # out = loop.run_until_complete(read_item('aHR0cHM6Ly93dzEuMTIzbW92aWVzLmNodXJjaC90aGUtcmVja29uaW5nLTIvMTIwNTY1Lw=='))
# # print(out)
# #len(list(set([i.strip() for i in open("D:\\Virtual\\Freela-Movies\\inputBabyDone.txt", 'r').readlines() if i.strip() != ''])))
# links_tested = list(set([i.strip() for i in open("D:\\Virtual\\Freela-Movies\\inputWrongTurn.txt", 'r').readlines() if i.strip() != '']))
# saida_bad = []
# saida_good = []
# saida_lin = []

# list_movies = [['https://movie4kto.icu/kinofilme-kostenlos-als-online-stream/minamata-2020/', 'minamata', 'tt9179096'],
# ['https://fmovies.li/watch/vK3ET4au/minamata-2021/watch-online-free.html', 'minamata', 'tt9179096'],
# ['https://5movies.cloud/film/minamata-41763/', 'minamata', 'tt9179096'],
# ['https://123movieweb.com/movie/minamata-2020/', 'minamata', 'tt9179096'],
# ['https://123moviesgo.ga/movie/minamata-109035', 'minamata', 'tt9179096'],
# ['https://0123netflix.pro/minamata-2020/', 'minamata', 'tt9179096'],
# ['https://0123netflix.pro/minamata-2020-2/', 'minamata', 'tt9179096'],
# ['https://ytsmovies.ws/the-ice-road-2021/', 'road', 'tt3758814'],
# ['https://yesmovies.vc/film/the-ice-road-42000/', 'road', 'tt3758814'],
# ['https://yesmovies.org/movies-the-ice-road-2021-yesmovies.html', 'road', 'tt3758814'],
# ['https://www1.movieorca.com/movie/the-ice-road-70428', 'road', 'tt3758814'],
# ['https://www.watch4freemovies.com/movie/the-ice-road-70428', 'road', 'tt3758814'],
# ['https://www.showboxmovies.net/movie/the-ice-road-70428', 'road', 'tt3758814'],
# ['https://w.123-movies.club/the-ice-road-2021/', 'road', 'tt3758814'],
# ['https://vmoveehd.com/movies/the-ice-road-2021/', 'road', 'tt3758814'],
# ['https://pw.unblockit.club/movie/699139-watch-the-ice-road', 'road', 'tt3758814'],
# ['https://pw.unblockit.club/movie/1142596-watch-the-ice-road', 'road', 'tt3758814'],
# ['https://putlockers.fm/watch/VdPV0DVx-the-ice-road.html', 'road', 'tt3758814'],
# ['https://putlockernew.net/watch/VdPV0DVx-the-ice-road.html', 'road', 'tt3758814'],
# ['https://prmovies.mx/the-ice-road-2021-Watch-online-on-prmovies/', 'road', 'tt3758814'],
# ['https://moviesjoy.to/movie/the-ice-road-70428', 'road', 'tt3758814'],
# ['https://movie4kto.icu/kinofilme-kostenlos-als-online-stream/the-ice-road-2021/', 'road', 'tt3758814'],
# ['https://kinox.live/film/the-ice-road-2021/', 'road', 'tt3758814'],
# ['https://fullmoviehd4k.com/movie/the-ice-road-70428', 'road', 'tt3758814'],
# ['https://fmovies.li/watch/oZ6a69IF/the-ice-road-2021/watch-online-free.html', 'road', 'tt3758814'],
# ['https://e123movies.com/watch/VdPV0DVx-the-ice-road.html', 'road', 'tt3758814'],
# ['https://bmovies.vip/film/the-ice-road-42000/', 'road', 'tt3758814'],
# ['https://ask4movie.cc/the-ice-road-2021/', 'road', 'tt3758814'],
# ['https://9kmovies.school/the-ice-road-2021-english-nf-hdrip-esub-720p-800mb-download/', 'road', 'tt3758814'],
# ['https://9kmovies.school/the-ice-road-2021-english-nf-hdrip-esub-480p-350mb-download/', 'road', 'tt3758814'],
# ['https://9kmovies.school/the-ice-road-2021-english-nf-hdrip-esub-1080p-1-4gb-download/', 'road', 'tt3758814'],
# ['https://5movies.cloud/film/the-ice-road-42000/', 'road', 'tt3758814'],
# ['https://123moviesgo.ga/movie/the-ice-road-293044', 'road', 'tt3758814'],
# ['https://0gomovies.io/movie/watch-the-ice-road-2021-online-gomovies/', 'road', 'tt3758814']]

# top_15 = [['https://e123movies.com/watch/wvnZpKzv-minamata.html', 'minamata', 'tt9179096'],
# ['https://putlockers.gs/watch/VdPV0DVx-the-ice-road.html', 'road', 'tt3758814'],
# ['https://5movies.bz/watch/VdPV0DVx-the-ice-road.html', 'road', 'tt3758814'],
# ['https://putlockers.fm/watch/VdPV0DVx-the-ice-road.html', 'road', 'tt3758814'],
# ['https://putlockernew.net/watch/VdPV0DVx-the-ice-road.html', 'road', 'tt3758814'],
# ['https://moviebb.net/watch/VdPV0DVx-the-ice-road.html', 'road', 'tt3758814'],
# ['https://w5.putlocker.to/79164-watch-the-ice-road-online-for-free-putlockers.html', 'road', 'tt3758814'],
# ['https://putlockerr.dev/the-ice-road/', 'road', 'tt3758814'],
# ['https://123movies.tools/the-ice-road-2021/', 'road', 'tt3758814'],
# ['https://prmovies.com/the-ice-road-2021-Watch-online-on-prmovies/', 'road', 'tt3758814'],
# ['https://prmovies.io/the-ice-road-2021-Watch-online-on-prmovies/', 'road', 'tt3758814'],
# ['https://0123netflix.pro/the-ice-road-2021/', 'road', 'tt3758814'],
# ['https://putlockernew.site/watch-movie/the-ice-road-2021_cw9q88eja/976x9dx-full-movie-online', 'road', 'tt3758814'],
# ['https://123movies.navy/the-ice-road/141038/', 'road', 'tt3758814'],
# ['https://123movies4u.icu/the-ice-road/2021/', 'road', 'tt3758814']]

#for movie in list_movies+top_15:
#    try:
#        saida_lin = generalista(base64.b64encode(bytes(movie[0],encoding='utf-8')), q_string=movie[1], q_imdb=movie[2])
#    except:
#        print("-"*25)
#        os.system('pkill -f chrome')
#        print("-"*25)
#    else:
#        print("*"*25)
#        print('ACERTO',  movie[0])
#        print(saida_lin)
#        print("*"*25)

# saida_lin = generalista('aHR0cHM6Ly9vcGVubG9hZG1vdmllcy5jeC93YXRjaC1maWxtL21pbmFtYXRhLTIwMjAv', q_string='Minamata', q_imdb='tt9179096')
# print(saida_lin)
# #print(generalista(base64.b64encode(bytes('https://openloadfreetv.me/movies/the-father/',encoding='utf-8'))))
# import datetime
# for innerLink in links_tested:
#     saida_lin = []
#     print('testando o link', innerLink, datetime.datetime.now())
#     #try:
#     try:
#         if testCloudFlare(innerLink):
#             print('CloudFlare')
#             continue
#     except:
#         pass
#     try:
#         saida_lin = generalista(base64.b64encode(bytes(innerLink,encoding='utf-8')))
#     except:
#         saida_lin = json.dumps({"list_of_links": "PageNotTreated"})
#     saida_lin = json.loads(saida_lin)
#     print(saida_lin)
#     print('#generalist'*25)
#     if 'list_of_links' in saida_lin.keys():
#         if saida_lin['list_of_links'] != [] and saida_lin['list_of_links'] != "CloudFlare" and saida_lin['list_of_links'] != "PageEmpty" and saida_lin['list_of_links'] != "PageNotTreated" and saida_lin['list_of_links'] != "Page not correctly encoded.":
#             saida_good.append(innerLink)
#             aux = open("D:\\Virtual\\Freela-Movies\\saida_good-gene7.txt", 'a')
#             aux.write(innerLink+"\n")
#             aux.write(str(saida_lin)+"\n")
#             aux.close()
#         else:
#             saida_bad.append(innerLink)
#             aux = open("D:\\Virtual\\Freela-Movies\\saida_bad-gene7.txt", 'a')
#             aux.write(innerLink+"\n")
#             aux.write(str(saida_lin)+"\n")
#             aux.close()
#     else:
#             saida_bad.append(innerLink)
#             aux = open("D:\\Virtual\\Freela-Movies\\saida_bad-gene7.txt", 'a')
#             aux.write(innerLink+"\n")
#             aux.write(str(saida_lin)+"\n")
#             aux.close()
    # except:
    #     continue
    #try:
    # loop = asyncio.get_event_loop()
    # saida_lin = loop.run_until_complete(read_item(base64.b64encode(bytes(innerLink,encoding='utf-8'))))
    # print(saida_lin)
    # print('#especialist'*25)
    # if saida_lin == [] or saida_lin == {"list_of_links": "PageEmpty"} or saida_lin == {"list_of_links": "CloudFlare"}or saida_lin == {"list_of_links": "PageNotTreated"} or saida_lin == "Page not correctly encoded.":
    #     saida_bad.append(innerLink)
    #     aux = open("D:\\Virtual\\Freela-Movies\\saida_bad-especia2.txt", 'a')
    #     aux.write(innerLink+"\n")
    #     aux.close()
    # else:
    #     saida_good.append(innerLink)
    #     aux = open("D:\\Virtual\\Freela-Movies\\saida_good-especia2.txt", 'a')
    #     aux.write(innerLink+"\n")
    #     aux.close()
    #except:
    #   continue
